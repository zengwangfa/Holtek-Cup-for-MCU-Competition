#include "ht32f1655_56.h" 
#include "config.h"

#ifndef _KEY_H
#define _KEY_H


#ifndef _KEY_C

#endif

void KeyScan(void);
void KeyDriver(void);

#endif
