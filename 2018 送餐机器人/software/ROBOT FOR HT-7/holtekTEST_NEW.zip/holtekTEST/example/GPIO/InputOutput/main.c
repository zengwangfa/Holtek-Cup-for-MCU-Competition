#include "ht32.h"
#include "ht32_board.h"
#include "config.h"
#include "action.h"
#include "controll_main.h"
#include "key.h"


 
int main(void)
{ 
	System_Init();
	Port_Init();
	Init();

  while (1)
  {
     
   
		KeyDriver();     
	}
}

#if (HT32_LIB_DEBUG == 1)
/*********************************************************************************************************//**
  * @brief  Report both the error name of the source file and the source line number.
  * @param  filename: pointer to the source file name.
  * @param  uline: error line source number.
  * @retval None
  ***********************************************************************************************************/
void assert_error(u8* filename, u32 uline)
{
  /*
     This function is called by IP library that the invalid parameters has been passed to the library API.
     Debug message can be added here.
  */

  while (1)
  {
  }
}
#endif


void delay(void)
{
 	unsigned int i = 100;
	while(i--);
}

void delayX(void)
{
	unsigned int i,j;
	for(j=0;j<150;j++)
	{
	for(i=0;i<50000;i++);
	}
}
 void ZMoveback(void)
{
	
 	  Zred = 0;   
		Zblack = 1; 
    while(Zb == 1);
	  Zblack = 0;  	 

}

void delayY(void)
{
    unsigned int i,j;
	  for(j=0;j<3;j++)
	  {
			  for(i=0;i<5000;i++);
	  }
}

void ZMovefront(void)
{
    Zred = 1;   
		Zblack = 0;  
	  while(Zf == 1);
	  Zred = 0; 
}


void Init(void)
{
    Cx = 1;     //x,y��Ƭѡ0�Ͽ���1Ϊ�Ͽ�
	  Cy = 1;
	  Zred = 0;   //Z���˶�����λ
	  Zblack = 0;
	
}
 void System_Init(void)
 {
	FlagStatus TmpStatus = RESET;
  CKCU_PeripClockConfig_TypeDef CKCUClock = {{0}};
	CKCUClock.Bit.BFTM0      = 1;
	CKCUClock.Bit.BFTM1      = 1;
	CKCUClock.Bit.PA         = 1;
  CKCUClock.Bit.PB         = 1;
  CKCUClock.Bit.PC         = 1;
	CKCUClock.Bit.PD         = 1;
	CKCUClock.Bit.PE        = 1;
  CKCUClock.Bit.AFIO       = 1;
  CKCUClock.Bit.BKP        = 1;
  CKCU_PeripClockConfig(CKCUClock, ENABLE);

}
void Port_Init(void)
{	
/*����������λPC(6 7)*/
  /* Configure AFIO mode of input pins                                                                      */
  AFIO_GPxConfig(GPIO_PC, AFIO_PIN_0, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PC, AFIO_PIN_1, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PC, AFIO_PIN_2, AFIO_MODE_DEFAULT);
	AFIO_GPxConfig(GPIO_PC, AFIO_PIN_3, AFIO_MODE_DEFAULT);
	AFIO_GPxConfig(GPIO_PC, AFIO_PIN_4, AFIO_MODE_DEFAULT);
	AFIO_GPxConfig(GPIO_PC, AFIO_PIN_5, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PC, AFIO_PIN_6, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PC, AFIO_PIN_7, AFIO_MODE_DEFAULT);
 

  /* Configure GPIO direction of input pins                                                                 */
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_0, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_1, GPIO_DIR_IN); 
	GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_2, GPIO_DIR_IN);
	GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_3, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_4, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_5, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_6, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOC, GPIO_PIN_7, GPIO_DIR_IN);
 

  /* Configure GPIO pull resistor of input pins                                                             */
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_0, GPIO_PR_UP);
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_1, GPIO_PR_UP);
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_2, GPIO_PR_UP);
	GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_3, GPIO_PR_UP);
	GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_4, GPIO_PR_UP);
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_5, GPIO_PR_UP);
	GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_6, GPIO_PR_UP);
  GPIO_PullResistorConfig(HT_GPIOC, GPIO_PIN_7, GPIO_PR_UP);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_0, ENABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_1, ENABLE);
	GPIO_InputConfig(HT_GPIOC, GPIO_PIN_2, ENABLE);
	GPIO_InputConfig(HT_GPIOC, GPIO_PIN_3, ENABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_4, ENABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_5, ENABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_6, ENABLE);
  GPIO_InputConfig(HT_GPIOC, GPIO_PIN_7, ENABLE);
	
/*����ǰ�����˿�������*/	
	  /* Configure AFIO mode of output pins                                                                     */
  AFIO_GPxConfig(GPIO_PB, AFIO_PIN_0, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PB, AFIO_PIN_1, AFIO_MODE_DEFAULT);
	AFIO_GPxConfig(GPIO_PB, AFIO_PIN_2, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PB, AFIO_PIN_3, AFIO_MODE_DEFAULT);
	AFIO_GPxConfig(GPIO_PB, AFIO_PIN_4, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PB, AFIO_PIN_5, AFIO_MODE_DEFAULT);
	
  

  /* Configure GPIO direction of output pins                                                                */
  GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_0, GPIO_DIR_OUT);
  GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_1, GPIO_DIR_OUT);
	GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_2, GPIO_DIR_OUT);
  GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_3, GPIO_DIR_OUT);
	GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_4, GPIO_DIR_OUT);
	GPIO_DirectionConfig(HT_GPIOB, GPIO_PIN_5, GPIO_DIR_OUT);
	
	/*������̶˿�PA����*/
	AFIO_GPxConfig(GPIO_PA, AFIO_PIN_0, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_1, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_2, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_3, AFIO_MODE_DEFAULT);
	AFIO_GPxConfig(GPIO_PA, AFIO_PIN_4, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_5, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_6, AFIO_MODE_DEFAULT);
  AFIO_GPxConfig(GPIO_PA, AFIO_PIN_7, AFIO_MODE_DEFAULT);
	
	GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_0, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_1, GPIO_DIR_IN); 
	GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_2, GPIO_DIR_IN);
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_3, GPIO_DIR_IN);
	GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_4, GPIO_DIR_OUT);
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_5, GPIO_DIR_OUT); 
	GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_6, GPIO_DIR_OUT);
  GPIO_DirectionConfig(HT_GPIOA, GPIO_PIN_7, GPIO_DIR_OUT);
	
	GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_0, GPIO_PR_UP);
  GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_1, GPIO_PR_UP);
  GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_2, GPIO_PR_UP);
	GPIO_PullResistorConfig(HT_GPIOA, GPIO_PIN_3, GPIO_PR_UP);
	GPIO_InputConfig(HT_GPIOA, GPIO_PIN_0, ENABLE);
  GPIO_InputConfig(HT_GPIOA, GPIO_PIN_1, ENABLE);
	GPIO_InputConfig(HT_GPIOA, GPIO_PIN_2, ENABLE);
  GPIO_InputConfig(HT_GPIOA, GPIO_PIN_3, ENABLE);
	
	/*���Գ����Ƿ�����*/
	/*AFIO_GPxConfig(GPIO_PD, AFIO_PIN_4, AFIO_MODE_DEFAULT);
	GPIO_DirectionConfig(HT_GPIOD, GPIO_PIN_4, GPIO_DIR_OUT);
		AFIO_GPxConfig(GPIO_PD, AFIO_PIN_5, AFIO_MODE_DEFAULT);
	GPIO_DirectionConfig(HT_GPIOD, GPIO_PIN_5, GPIO_DIR_OUT);
		AFIO_GPxConfig(GPIO_PD, AFIO_PIN_6, AFIO_MODE_DEFAULT);
	GPIO_DirectionConfig(HT_GPIOD, GPIO_PIN_6, GPIO_DIR_OUT);*/
		AFIO_GPxConfig(GPIO_PD, AFIO_PIN_7, AFIO_MODE_DEFAULT);
	GPIO_DirectionConfig(HT_GPIOD, GPIO_PIN_7, GPIO_DIR_OUT);
	
	HT32F_DVB_LEDInit(HT_LED1);   //���������ʼ��
	//HT32F_DVB_LEDInit(HT_LED2);

	

	NVIC_EnableIRQ(BFTM1_IRQn);     //��ʱʹ��
	BFTM_SetCompare(HT_BFTM1, SystemCoreClock/15000 * 5);//����1.5Khz���壬�ö�ʱ��1�����ȼ����ڶ�ʱ��0
  BFTM_SetCounter(HT_BFTM1, 0);                        
  BFTM_IntConfig(HT_BFTM1, ENABLE);//ENABLEΪ1
  BFTM_EnaCmd(HT_BFTM1, ENABLE);
	
	NVIC_EnableIRQ(BFTM0_IRQn);     //��ʱʹ��
	BFTM_SetCompare(HT_BFTM0, SystemCoreClock/10000 * 5);//0.5ms��ʱ
  BFTM_SetCounter(HT_BFTM0, 0);                        
  BFTM_IntConfig(HT_BFTM0, ENABLE);//ENABLEΪ1
  BFTM_EnaCmd(HT_BFTM0, ENABLE);
}
