/*********************************************************************************************************//**
 * @file    PWRCU/DeepSleepMode1/ht32f165x_it.c
 * @version $Rev:: 929          $
 * @date    $Date:: 2015-09-16 #$
 * @brief   This file provides all interrupt service routine.
 *************************************************************************************************************
 * @attention
 *
 * Firmware Disclaimer Information
 *
 * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
 *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
 *    other intellectual property laws.
 *
 * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
 *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
 *    other than HOLTEK and the customer.
 *
 * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
 *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
 *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
 *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
 *
 * <h2><center>Copyright (C) 2014 Holtek Semiconductor Inc. All rights reserved</center></h2>
 ************************************************************************************************************/

/* Includes ------------------------------------------------------------------------------------------------*/
#include "ht32.h"
#include "ht32_board.h"

/** @addtogroup HT32_Series_Peripheral_Examples HT32 Peripheral Examples
  * @{
  */

/** @addtogroup PWRCU_Examples PWRCU
  * @{
  */

/** @addtogroup DeepSleepMode1
  * @{
  */


/* Private variables ---------------------------------------------------------------------------------------*/
vu32 wTimingDelay = 0;

/* Global functions ----------------------------------------------------------------------------------------*/
/*********************************************************************************************************//**
 * @brief   This function handles NMI exception.
 * @retval  None
 ************************************************************************************************************/
void NMI_Handler(void)
{
}

/*********************************************************************************************************//**
 * @brief   This function handles Hard Fault exception.
 * @retval  None
 ************************************************************************************************************/
void HardFault_Handler(void)
{
  while (1);
}

/*********************************************************************************************************//**
 * @brief   This function handles Memory Manage exception.
 * @retval  None
 ************************************************************************************************************/
void MemManage_Handler(void)
{
  while (1);
}

/*********************************************************************************************************//**
 * @brief   This function handles Bus Fault exception.
 * @retval  None
 ************************************************************************************************************/
void BusFault_Handler(void)
{
  while (1);
}

/*********************************************************************************************************//**
 * @brief   This function handles Usage Fault exception.
 * @retval  None
 ************************************************************************************************************/
void UsageFault_Handler(void)
{
  while (1);
}

/*********************************************************************************************************//**
 * @brief   This function handles SVCall exception.
 * @retval  None
 ************************************************************************************************************/
void SVC_Handler(void)
{
}

/*********************************************************************************************************//**
 * @brief   This function handles Debug Monitor exception.
 * @retval  None
 ************************************************************************************************************/
void DebugMon_Handler(void)
{
}

/*********************************************************************************************************//**
 * @brief   This function handles PendSVC exception.
 * @retval  None
 ************************************************************************************************************/
void PendSV_Handler(void)
{
}

/*********************************************************************************************************//**
 * @brief   This function handles SysTick Handler.
 * @retval  None
 ************************************************************************************************************/
void SysTick_Handler(void)
{
  wTimingDelay--;
}

/*********************************************************************************************************//**
 * @brief   This function handles EXTI Events Wakeup interrupt.
 * @retval  None
 * @details The EXTI Event Wakeup interrupt handler as following:
 *    - If the EXTI Channel wakeup event occurred
 *      - Disable button EXTI Channel wakeup event since it's active on level.
 *      - Clear the Key Button EXTI channel event wakeup flag.
 *      - Toggle LED2.
 *    - If the RTC compare match event occurred
 *      - Toggle LED3.
 * @note The RTC_SR is clear by read action.
 ************************************************************************************************************/
void EVWUP_IRQHandler(void)
{
  if (EXTI_GetWakeupFlagStatus(KEY1_BUTTON_EXTI_CHANNEL) )
  {
    /* Disable button EXTI Channel wakeup event to avoid re-entry                                           */
    EXTI_WakeupEventConfig(KEY1_BUTTON_EXTI_CHANNEL, EXTI_WAKEUP_LOW_LEVEL, DISABLE);

    /* Clear the Key Button EXTI channel event wakeup flag                                                  */
    EXTI_ClearWakeupFlag(KEY1_BUTTON_EXTI_CHANNEL);

    /* Toggle LED2                                                                                          */
    HT32F_DVB_LEDToggle(HT_LED2);
  }
  else if (RTC_GetFlagStatus() & RTC_FLAG_CM)
  {
    /* Toggle LED3                                                                                          */
    HT32F_DVB_LEDToggle(HT_LED3);
  }
}


/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */
